﻿
using OpenQA.Selenium;

namespace SimpleSimpleSelenium.Page
{
    public class LoginPage : BasePage
    {
        private By xpathInputUsername = By.XPath("//input[@name='username']");
        private By xpathInputPassword = By.XPath("//input[@name='password']");
        private By xpathSubmitButton = By.XPath("//button[contains(@class, 'login-button')]");
        private By xpathErrorMessage = By.XPath("//div[@role='alert']");

        public LoginPage(IWebDriver _driver) : base(_driver)
        {
        }

        public void InputUsername(string username)
        {
            driver.FindElement(xpathInputUsername).SendKeys(username);
        }

        public void InputPassword(string password)
        {
            driver.FindElement(xpathInputPassword).SendKeys(password);
        }

        public void ClickLogin()
        {
            driver.FindElement(xpathSubmitButton).Click();
        }

        public void VerifyLoginUsernameAndPassword(string username, string password)
        {
            InputUsername(username);
            InputPassword(password);
            ClickLogin();
        }

        public bool VerifyErrorMessageIsDisplay()
        {
            return driver.FindElement(xpathErrorMessage).Displayed;
        }
    }
}
