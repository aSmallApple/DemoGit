﻿
using OpenQA.Selenium;

namespace SimpleSimpleSelenium.Page
{
    public class BasePage
    {
        protected IWebDriver driver;

        public BasePage(IWebDriver _driver)
        {
            driver = _driver;
        }
    }
}
