﻿
using OpenQA.Selenium;

namespace SimpleSimpleSelenium.Page
{
    public class DashboardPage : BasePage
    {
        private By xpathLoginSuccess = By.XPath("//h6[text() = 'Dashboard']");
        private By xpathTimeAtWork = By.XPath("//p[contains(., 'Time at Work')]");
        private By XpathMyActions = By.XPath("//p[contains(., 'My Actions')]");
        private By xpathQuickLaunch = By.XPath("//p[contains(., 'Quick Launch')]");
        private By xpathBuzzLastestPost = By.XPath("//p[contains(., 'Buzz Latest Posts')]");
        private By xpathEmployeesOnLeaveToday = By.XPath("//p[contains(., 'Employees on Leave Today')]");
        private By xpathEmployeesDistributionBySubUnit = By.XPath("//p[contains(., 'Employee Distribution by Sub Unit')]");
        private By xpathEmployeesDistributionByLocation = By.XPath("//p[contains(., 'Employee Distribution by Location')]");

        public DashboardPage(IWebDriver _driver) : base(_driver)
        {
        }
        // Verify Dashboard is displayed:
        public bool IsDashboardPageDisplay()
        {
            return driver.FindElement(xpathLoginSuccess).Displayed;
        }

        // Verify Time At Work widget is displayed:
        public bool IsTimeAtWorkDisplay()
        {
            return driver.FindElement(xpathTimeAtWork).Displayed;
        }

        // Verify My Actions widget is displayed:
        public bool IsMyActionsDisplay()
        {
            return driver.FindElement(XpathMyActions).Displayed;
        }

        // Verify Quick Launch widget is displayed:
        public bool IsQuickLaunchDisplay()
        {
            return driver.FindElement(xpathQuickLaunch).Displayed;
        }

        // Verify Buzz Lastest Post widget is displayed:
        public bool IsBuzzLastestPostDisplay()
        {
            return driver.FindElement(xpathBuzzLastestPost).Displayed;
        }

        // Verify Employees On Leave Today widget is displayed:
        public bool IsEmployeesOnLeaveTodayDisplay()
        {
            return driver.FindElement(xpathEmployeesOnLeaveToday).Displayed;
        }

        //Verify Employees Distribution By Sub Unit widget is displayed:
        public bool IsEmployeeDistributionBySubUnit_Display()
        {
            return driver.FindElement(xpathEmployeesDistributionBySubUnit).Displayed;
        }

        // Verify Employees Distribution By Location is displayed:
        public bool IsEmployeesDistributionByLocation_Display()
        {
            return driver.FindElement(xpathEmployeesDistributionByLocation).Displayed;
        }
    }
}
