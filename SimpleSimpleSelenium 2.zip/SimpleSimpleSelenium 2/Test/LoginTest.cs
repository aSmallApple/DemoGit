﻿using SimpleSimpleSelenium.Page;

namespace SimpleSimpleSelenium.Test
{
    [TestClass]
    public class LoginTest : BaseTest
    {

        [TestMethod("TC01: Login with valid Information")]
        public void VerifyValidUser()
        {
            // Input Valid User Information:
            loginPage = new LoginPage(browser.Driver);
            dashboardPage = new DashboardPage(browser.Driver);
            loginPage.VerifyLoginUsernameAndPassword("Admin", "admin123");

            // Verify Login Success:
            Assert.IsTrue(dashboardPage.IsDashboardPageDisplay());
        }

        [TestMethod("TC01: Login with invalid Information")]
        public void VerifyInvalidUser()
        {
            // Input Valid User Information:
            loginPage = new LoginPage(browser.Driver);
            dashboardPage = new DashboardPage(browser.Driver);
            loginPage.VerifyLoginUsernameAndPassword("Admin", "admin");

            // Verify Login Fail:
            Assert.IsTrue(loginPage.VerifyErrorMessageIsDisplay());

            //Verify Login Fail 2:

            //try
            //{
            //    browser.Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(1);
            //    Assert.AreEqual(browser.Driver.FindElements(xpathLoginSuccess).Count, 0);
            //}
            //catch
            //{
            //    Assert.Fail();
            //}
            //finally
            //{
            //    browser.Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            //}
        }

    }

}
