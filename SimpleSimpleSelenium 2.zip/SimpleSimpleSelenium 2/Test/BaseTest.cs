﻿using SimpleSimpleSelenium.Page;
using WebDriverHelper;

namespace SimpleSimpleSelenium.Test
{
    public class BaseTest
    {
        protected BrowserHelper browser;
        protected LoginPage loginPage;
        protected DashboardPage dashboardPage;
        [TestInitialize]
        public void TestInitialize()
        {
            browser = new BrowserHelper();
            browser.OpenBrowser("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        }

        [TestCleanup]
        public void TestCleanup()
        {
            browser.QuitBrowser();
        }
    }
}
