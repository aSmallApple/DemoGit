﻿

using SimpleSimpleSelenium.Page;

namespace SimpleSimpleSelenium.Test
{
    [TestClass]
    public class DashboardTest : BaseTest
    {
        [TestMethod("TC10: Verify Time At Work widget is displayed")]
        public void VerifyTimeAtWorkDisplay()
        {
            loginPage = new LoginPage(browser.Driver);
            dashboardPage = new DashboardPage(browser.Driver);
            loginPage.VerifyLoginUsernameAndPassword("Admin", "admin123");

            // Check Dashboard is displayed:
            Assert.IsTrue(dashboardPage.IsDashboardPageDisplay());
            // Verify Time At Work widget is displayed:
            Assert.IsTrue(dashboardPage.IsTimeAtWorkDisplay());
        }

        [TestMethod("TC11: Verify My Actions widget is displayed")]
        public void VerifyMyActionsDisplay()
        {
            loginPage = new LoginPage(browser.Driver);
            dashboardPage = new DashboardPage(browser.Driver);
            loginPage.VerifyLoginUsernameAndPassword("Admin", "admin123");

            // Check Dashboard is displayed:
            Assert.IsTrue(dashboardPage.IsDashboardPageDisplay());

            // Verify My Actions widget is displayed:
            Assert.IsTrue(dashboardPage.IsMyActionsDisplay());
        }

        [TestMethod("TC12: Verify Quick Launch widget is displayed")]
        public void VerifyQuickLaunchDisplay()
        {
            loginPage = new LoginPage(browser.Driver);
            dashboardPage = new DashboardPage(browser.Driver);
            loginPage.VerifyLoginUsernameAndPassword("Admin", "admin123");

            // Check Dashboard is displayed:
            Assert.IsTrue(dashboardPage.IsDashboardPageDisplay());

            // Verify My Actions widget is displayed:
            Assert.IsTrue(dashboardPage.IsQuickLaunchDisplay());
        }

        [TestMethod("TC13: Verify Buzz Lastest Post widget is displayed")]
        public void VerifyBuzzLastestPostDisplay()
        {
            loginPage = new LoginPage(browser.Driver);
            dashboardPage = new DashboardPage(browser.Driver);
            loginPage.VerifyLoginUsernameAndPassword("Admin", "admin123");

            // Check Dashboard is displayed:
            Assert.IsTrue(dashboardPage.IsDashboardPageDisplay());

            // Verify Buzz Lastest Post widget is displayed:
            Assert.IsTrue(dashboardPage.IsBuzzLastestPostDisplay());
        }

        [TestMethod("TC14: Verify Employees On Leave Today widget is displayed")]
        public void VerifyEmployessOnLeaveToday_Display()
        {
            loginPage = new LoginPage(browser.Driver);
            dashboardPage = new DashboardPage(browser.Driver);
            loginPage.VerifyLoginUsernameAndPassword("Admin", "admin123");

            // Check Dashboard is displayed:
            Assert.IsTrue(dashboardPage.IsDashboardPageDisplay());

            // Verify Employees On Leave Today widget is displayed:
            Assert.IsTrue(dashboardPage.IsEmployeesOnLeaveTodayDisplay());
        }

        [TestMethod("TC15: Verify Employees Distribution by Sub Unit is displayed")]
        public void VerifyEmployeesDistributionBySubUnit_Display()
        {
            loginPage = new LoginPage(browser.Driver);
            dashboardPage = new DashboardPage(browser.Driver);
            loginPage.VerifyLoginUsernameAndPassword("Admin", "admin123");

            // Check Dashboard is displayed:
            Assert.IsTrue(dashboardPage.IsDashboardPageDisplay());

            // Verify Employees Distribution By Sub Unit is displayed:
            Assert.IsTrue(dashboardPage.IsEmployeeDistributionBySubUnit_Display());
        }

        [TestMethod("TC16: Verify Employees Distribution by Location is displayed ")]
        public void VerifyEmployeesDistributionByLocation_Display()
        {
            loginPage = new LoginPage(browser.Driver);
            dashboardPage = new DashboardPage(browser.Driver);
            loginPage.VerifyLoginUsernameAndPassword("Admin", "admin123");

            // Check Dashboard is displayed:
            Assert.IsTrue(dashboardPage.IsDashboardPageDisplay());

            // Verify Employees Distribution by Location is displayed:
            Assert.IsTrue(dashboardPage.IsEmployeesDistributionByLocation_Display());
        }
    }
}
